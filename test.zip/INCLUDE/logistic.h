#ifndef _LOGISTIC_H_
#define _LOGISTIC_H_

void logistic_ad(int *fun);
void logistic_us(int *fun);
void wlcx(int *op,int *t,int*t2,int *insided);
void sh(int *op,int *t);
void fh(int *op,int *insided);
#endif