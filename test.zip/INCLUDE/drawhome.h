#ifndef _DRAWHOME_H_
#define _DRAWHOME_H_

void drawhome(void);
void drawregister(void);

#endif
