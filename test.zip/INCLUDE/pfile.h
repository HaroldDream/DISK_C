#ifndef _PURCHASEF_H_
#define _PURCHASEF_H_

int show_plist(int cp, int type);
int show_order(int cp, int day);
int show_flist(int num, int cp);

#endif