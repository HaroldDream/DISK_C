#ifndef _DRAW_ADMIN_
#define _DRAW_ADMIN_

void drawad(int num, int op);
void drawad_purchase(int op);
void drawad_info(int op);
void drawad_storage(int op);
void drawad_logistic(int op);

#endif