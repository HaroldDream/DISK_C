#ifndef _MAIN_H_
#define _MAIN_H_

//*开始的主页�?


#include "database.h" //todo数据�?
#include "home.h"  //todo主页和登�?
/*#include "register.h"  //todo注册
#include "user.h" //todo食堂界面
#include "admin.h" //todo后勤管理员界�?
*/

void main();//

#endif
