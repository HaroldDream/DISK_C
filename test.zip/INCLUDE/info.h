#ifndef _INFO_H_
#define _INFO_H_

void info_ad(int *fun);
void ddcx(int *op, int *day);
void info_us(int *fun);

#endif