#ifndef _STORAGE_H_
#define _STORAGE_H_

void storage_ad(int *fun);
void storage_us(int *fun);
void kccx(int *op);
void rk(int *op);
void ck(int *op);

#endif