#ifndef _USERDATA_H_
#define _USERDATA_H_

void input_data(char* username, char* phone, char* password,int mode);

#endif