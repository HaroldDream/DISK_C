#ifndef _PURCHASE_H_
#define _PURCHASE_H_

void purchase(int *fun);
void cgml(int *op, int *type);
void xtyc(int *op, int *num);
void cgd(int *op, int *day);
int pop(int n);

#endif