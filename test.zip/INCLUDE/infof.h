#ifndef _INFOF_H_
#define _INFOF_H_

int show_ddcx(int cp, int day);

#endif