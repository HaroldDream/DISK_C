#ifndef _DRAWUSER_H_
#define _DRAWUSER_H_

void drawuser(int num, int op);
void drawuser_info(int op);
void drawuser_storage(int op);
void drawuser_logistic(int op);

#endif