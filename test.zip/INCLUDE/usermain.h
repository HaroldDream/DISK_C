#ifndef _USERMAIN_H_
#define _USERMAIN_H_

void usermain(int *page);

#endif