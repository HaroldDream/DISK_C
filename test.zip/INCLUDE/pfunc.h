#ifndef _PFUNC_H_
#define _PFUNC_H_

int up_order(int n, int a, int page);
int forecast(int *y,int *yy);
int up_flist(int ctn, int n, int page, int a);
int sum();

#endif