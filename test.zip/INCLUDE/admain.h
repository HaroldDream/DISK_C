#ifndef _ADMAIN_H_
#define _ADMAIN_H_

void admain(int *page);

#endif