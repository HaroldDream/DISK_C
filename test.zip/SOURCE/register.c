#include "common.h"
#include "database.h"
#include "drawhome.h"
#include "register.h"
#include "input.h"
#include "judge.h"

/********************************************
DESCRIPTION:ע��
INPUT:*func
RETURN:
********************************************/

void registermain (int *page)
{
    char UNAME[15] = { '\0' };   //*6-10λ���û���
	char PHONE[20] = { '\0' };   //*11λ����ϵ��ʽ
	char PASSWORD[20] = { '\0' };   //*6-10λ������
	char CPASSWORD[20] = { '\0' };  //*6-10λ��ȷ������
	int box1 = 0;            //*�����״̬
	int box2 = 0;
	int box3 = 0;
	int box4 = 0;
	int num;
	int mode;       //*1Ϊʳ��2Ϊ����

	clrmous(MouseX,MouseY);
	delay(100);
	drawregister();
	

    while (1)
	{
		newmouse(&MouseX, &MouseY, &press);
		
        if (MouseX > 240 && MouseX < 240+220 && MouseY>120 && MouseY < 120+40) //*�û�����
		{    
			 if(mouse_press(240,120,240+220,120+40) == 2)
           
		    {
				MouseS = 2;
			    if (num == 0 && box1 == 0) 
			    {
					num = 3;
					selectbutton_register(240,120,240+220,120+40,LIGHTGRAY,num);
			    }
		    	continue;
		    }

			else if (mouse_press(240,120,240+220,120+40) == 1)      
			{
				MouseS = 0;
				selectbutton_register(240,120,240+220,120+40, LIGHTGRAY, 1);
				UNAME[0] = '\0';
				input(UNAME, 240 , 120 , 10, LIGHTGRAY);//�������뺯��
				if(strlen(UNAME) != 0)                  //�ж��Ƿ�����
					box1 = 1;
				else
					box1 = 0;
				continue;
			}
		}

		
         if (MouseX > 240 && MouseX < 240+220 && MouseY>120+60 && MouseY < 120+60+40) //*��ϵ�绰��
		{    
			if (mouse_press(240,120+60,240+220,120+60+40) == 2)     
			{
				MouseS = 2;
				if (num == 0 && box2 == 0)                  //num = 0��ֹ�ظ�����
				{
					selectbutton_register(240,120+60,240+220,120+60+40, LIGHTGRAY, 2);
					num = 2;
				}
				continue;
			}

			else if (mouse_press(240,120+60,240+220,120+60+40) == 1)      
			{
				MouseS = 0;
				selectbutton_register(240,120+60,240+220,120+60+40, LIGHTGRAY, 2);
				PHONE[0] = '\0';
				input(PHONE, 240 , 120+60 , 11, LIGHTGRAY);
				if(strlen(PHONE) != 0)            //�ж��Ƿ�����
					box2 = 1;
				else
					box2 = 0;
				continue;
			}
		}
        
       
	    if (MouseX > 240 && MouseX < 240+220 && MouseY>120+120 && MouseY < 120+120+40) //*�����
		{    
			if (mouse_press(240,120+120,240+220,120+120+40) == 2)     
			{
				MouseS = 2;
				if (num == 0 && box3 == 0)                  //num = 0��ֹ�ظ�����
				{
					selectbutton_register(240,120+120,240+220,120+120+40, LIGHTGRAY, 3);
					num = 3;
				}
				continue;
			}

			else if (mouse_press(240,120+120,240+220,120+120+40) == 1)      
			{
				MouseS = 0;
				selectbutton_register(240,120+120,240+220,120+120+40, LIGHTGRAY, 3);
				PASSWORD[0] = '\0';
				inputmm(PASSWORD, 240 , 120+120 , 10, LIGHTGRAY);
				if(strlen(PASSWORD) != 0)            //�ж��Ƿ�����
					box3 = 1;
				else
					box3 = 0;
				continue;
			}
		}
       
	    if (MouseX > 240 && MouseX < 240+220 && MouseY>120+180 && MouseY < 120+180+40) //*ȷ�������
		{    
			if (mouse_press(240,120+180,240+220,120+180+40) == 2)     
			{
				MouseS = 2;
				if (num == 0 && box4 == 0)                  //num = 0��ֹ�ظ�����
				{
					selectbutton_register(240,120+180,240+220,120+180+40, LIGHTGRAY, 4);
					num = 4;
				}
				continue;
			}

			else if (mouse_press(240,120+180,240+220,120+180+40) == 1)      
			{
				MouseS = 0;
				selectbutton_register(240,120+180,240+220,120+180+40, LIGHTGRAY, 4);
				CPASSWORD[0] = '\0';
				inputmm(CPASSWORD, 240 , 120+180 , 10, LIGHTGRAY);
				if(strlen(CPASSWORD) != 0)             //�ж��Ƿ�����
					box4 = 1; 
				else
					box4 = 0;
				continue;
			}
		}

		if (MouseX > 182+60 && MouseX < 290+60 && MouseY> 362+2 && MouseY < 380+2)  //*ѡ��ע�����ģʽ
        {
            if(mouse_press(182+60,362+2,290+60,380+2) == 2)          
		    {
			    if (num == 0) 
			    {
				    MouseS = 1;	
			    }
		    	continue;
		    }
		    else if (mouse_press(182+60,362+2,290+60,380+2) == 1)
		    {
			    MouseS = 0;
				mode = 1; 
				selectmode_register(5);
                recoverbutton_register(6);   //*��֮ǰѡ�еĶ˰�ť�ָ�
			    continue;
		    }
		}

		if (MouseX > 302+60 && MouseX < 410+60 && MouseY> 362+2 && MouseY < 380+2)     //*ѡ��ע��ʳ��ģʽ
        {
            if(mouse_press(302+60,362+2,410+60,380+2) == 2)          
		    {
			    if (num == 0)
			    {
				    MouseS = 1;
			    }
		    	continue;
		    }
		    else if (mouse_press(302+60,362+2,410+60,380+2) == 1)
		    {
			    MouseS = 0;
				mode = 2; 
				selectmode_register(6);
                recoverbutton_register(5);   //*��֮ǰѡ�еĶ˰�ť�ָ�
			    continue;
		    }
		}
		
		if (MouseX > 280 && MouseX < 280+140 && MouseY>120+240+50 && MouseY < 120+240+40+50) //*ע���
	    {
			if(mouse_press(280,120+240+50,280+140,120+240+40+50) == 2)  
	        {
			    MouseS = 1;
		        continue;
		    }
		    else if(mouse_press(280,120+240+50,280+140,120+240+40+50) == 1 && box1*box2*box3*box4 == 1)    //��Ҫ�ĸ���������ע�������Ч
		    {
			    MouseS = 0;
				if (register_success(UNAME, PHONE , PASSWORD, CPASSWORD,mode))    //�ж��ĸ�ע�������Ƿ��������
				{
					setcolor(WHITE);
	                setfillstyle(SOLID_FILL, WHITE);  
                    bar(560-90+30,120+240+50,560+30-10,120+240+40+50);     
	                puthz(560+30-90-15,120+240+50+8,"ע��ɹ�",24,25,RED);
					delay(1000);
					*page = 0;
					return;
				}
				else
				{
					delay(1000);
					continue;
				}
		    }
		}
		
		if(mouse_press(560-90+30,120+240+50,560+30-10,120+240+40+50) == 2) //*���ؼ�  
		{
			MouseS = 1;
		    continue;
		}
		else if(mouse_press(560+30-90,120+240+50,560-10+30,120+240+40+50) == 1)
		{
			*page = 0;
			return;
		}
		
		else //*ѭ���ָ�
		{
			if (num != 0)
		    {
			   MouseS = 0;	
			   if (box1 == 0)
			   {
				    recoverbutton_register(1);
			   }
			   if (box2 == 0)
			   {
				    recoverbutton_register(2);
			   }
			   if (box3 == 0)
			   {
				    recoverbutton_register(3);
			   }
			   if (box4 == 0)
			   {
			    	recoverbutton_register(4);
			   }
			   num = 0;
		    }
		    if (MouseS != 0)
            {
            MouseS = 0;
            }
            continue;
		}
			 
	}
	
}


/********************************************
FUNCTION:selectbutton_register
DESCRIPTION: ע����水ť���ѡ��״̬����
INPUT:x1,y1,x2,y2,color1,num
RETURN:��
********************************************/
void selectbutton_register(int x1, int y1, int x2, int y2, int color1, int num)
{
	clrmous(MouseX, MouseY);
	delay(10);
    setcolor(WHITE);
	setfillstyle(SOLID_FILL, color1);
	bar(x1, y1, x2, y2);
	rectangle(x1, y1, x2, y2);	//*���Ʊ߿�

	switch (num)
	{
	case 1: //*�û�����
		break;
	case 2: //*��ϵ�绰��	    
	    break;
	case 3: //*�����
		break;
	case 4: //*ȷ�������
		break;
	default: 
		closegraph();
		printf("something runs wrong in selectbutton_register");
		exit(1);
	}
}

/********************************************
FUNCTION:recoverbutton_register
DESCRIPTION: ע�����ָ���ť���״̬����
INPUT:num
RETURN:��
********************************************/
void recoverbutton_register(int num)
{
	clrmous(MouseX, MouseY);
	switch (num)
	{
	case 1:   //*�û�����ָ�
	    setfillstyle(SOLID_FILL,WHITE);
		bar(240,120,240+220,120+40);
		setcolor(BLUE);
	    setlinestyle(SOLID_LINE, 0, 3);
	    rectangle(240,120,240+220,120+40);
		break;
	case 2:   //*��ϵ�绰��ָ�
	    setfillstyle(SOLID_FILL,WHITE);
		bar(240,120+60,240+220,120+60+40);
		setcolor(BLUE);
	    setlinestyle(SOLID_LINE, 0, 3);
	    rectangle(240,120+60,240+220,120+60+40);
		break;
	case 3:   //*�����ָ�
	    setfillstyle(SOLID_FILL,WHITE);
		bar(240,120+120,240+220,120+120+40);
		setcolor(BLUE);
	    setlinestyle(SOLID_LINE, 0, 3);
	    rectangle(240,120+120,240+220,120+120+40);
	    break;
	case 4:   //*ȷ�������ָ�
	    setfillstyle(SOLID_FILL,WHITE);
		bar(240,120+180,240+220,120+180+40);
		setcolor(BLUE);
	    setlinestyle(SOLID_LINE, 0, 3);
	    rectangle(240,120+180,240+220,120+180+40);
	    break;  
	case 5://*���ڶ˻ָ�
		setcolor(WHITE);
		setfillstyle(SOLID_FILL,WHITE);
		fillellipse(189+60,370+2,6,6);
	    break;  
	case 6://*ʳ�ö˻ָ�
		setcolor(WHITE);
		setfillstyle(SOLID_FILL,WHITE);
		fillellipse(309+60,370+2,6,6);
	    break;  

	}
}

/********************************************
FUNCTION:selectmode_register
DESCRIPTION: ��ʾ�˿ڱ�ѡ��״̬����
INPUT:num
RETURN:��
********************************************/
void selectmode_register(int num)
{
	clrmous(MouseX, MouseY);
	delay(10);
	setfillstyle(SOLID_FILL,RED);
	
	switch (num)
	{
	case 5:   //*���ڶ�ѡ��
	    fillellipse(189+60,370+2,5,5);
		//puthz(320,140,"��",48,30,WHITE);
		break;
	case 6:   //*ʳ�ö�ѡ��
	    fillellipse(309+60,370+2,5,5);
	    //puthz(320,140,"ʳ",48,30,WHITE);
	    break;
	default:
		closegraph();
		printf("something runs wrong in selectmode_home");
		exit(1);
	}
}